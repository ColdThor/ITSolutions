
<?php
//if (isset($_SESSION['userId']) and $_SESSION['userId']!=''):
    ?>



        <table id="usertable" style="margin-left: 20px; width: 98%;float:left; "   bgcolor="#02318e" >

            <thead>
            <!--  <style>
                table.dataTable td, table.dataTable th  {
                    border-top: 1px solid #d9d9d9;
                    border-bottom: 1px solid #ffffff;
                    border-left: 1px solid #d9d9d9;
                    border-right: 1px solid #ffffff;
                    border-collapse: collapse;
                }


            </style> -->
            <tr>
                <th>Číslo používateľa</th>
                <th>Meno a priezvisko</th>
                <th>Email</th>
                <th>Telefón</th>
                <th>Rola</th>
            </tr>
            </thead>
            <tbody>

            </tbody>
        </table>




    </div>


        <!-- SCRIPTY NA DATATABLES -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>


    <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/plug-ins/1.10.16/api/sum().js"></script>
    <script src="vendor/jquery/jquery-1.11.2.min.js" type="text/javascript"></script>





    <script type="text/javascript">

        // $("#usertable").append('<tfoot><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th><th></th></tfoot>');


        $(document).ready(function () {


            /* $('#usertable tfoot th').each(function() {
                 var title = $(this).text();
                 $(this).html('<input type="text" placeholder="Hľadať ' + title + '" />');
             }); */

            var table= $('#usertable').DataTable({




                dom: 'Blfrtip',
                lengthMenu: [[10, 25, 50,100,200,300,400], [10, 25, 50,100,200,300,400]],
                buttons: [
                    { extend: 'excel', text: 'Export do excelu', className: 'excelbutton',
                        exportOptions: {
                            columns: [0,1,2,3,4]
                        }
                    },
                    { extend: 'pdf', text: 'Export do PDF', className: 'excelbutton',
                        exportOptions: {
                            columns: [0,1,2,3,4]
                        }
                    }
                ],

                "ajax": "http://appnormit.visibly.sk/connecttovykresy.php",

                "serverSide": true,
                "order": [[ 0, "asc" ]],
                "columnDefs": [




                    {

                        "targets": 2,
                        "visible": false
                    },



                    {

                    {
                        "targets": 1,
                        "data": null,
                        "render": function (data, type, full, meta) {

                            return full[1]+" "+full[2];

                        }

                    }
                ],

                stateSave: true,




                language: {
                    search: "Hľadať:",
                    info:"Zobrazujem _START_ do _END_ zo _TOTAL_ záznamov",
                    lengthMenu:     "Zobraziť _MENU_ záznamov",
                    infoEmpty:      "Zobrazujem 0 do 0 z 0 záznamov",
                    infoFiltered:   "(filtrované z _MAX_ celkových záznamov)",
                    zeroRecords:    "Neboli nájdené žiadne zodpovedajúce záznamy",
                    paginate: {
                        next:       "Ďaľšia",
                        previous:   "Predchádzajúca",
                    }
                }

            } );

        } );



    </script>

<? //else: ?>
<!--
    <div align="center">
        <h1 style="color: #02318e">
            Žiadny používateľ nie je prihlásený! <br />
            Táto stránka je iba pre administrátorov!</h1>
    </div>
    -->
<? //endif; ?>



