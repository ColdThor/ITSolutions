

<?php

header("Content-Type: text/json; charset=UTF32_slovak_ci");
// DB table to use
$table = <<<EOT
 (
  SELECT 
    *
   FROM
   user
   LEFT JOIN
   user_group ON
   user.id_user_group = user_group.id_user_group
 
 ) temp
EOT;

// Table's primary key
$primaryKey = 'id_user';


$columns = array(
    array( 'db' => 'id_user', 'dt' => 0 ),
    array( 'db' => 'first_name',  'dt' => 1 ),
    array( 'db' => 'last_name',  'dt' => 2 ),
    array( 'db' => 'email',  'dt' => 3 ),
    array( 'db' => 'telephone',  'dt' => 4 ),
    array( 'db' => 'title',   'dt' => 5 ),
);

// SQL server connection information
$sql_details = array(
    'user' => 'root',
    'pass' => '',
    'db'   => 'reality',
    'host' => '127.0.0.1'
);


require('ssp.class.php');

echo json_encode(
    SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns )
);